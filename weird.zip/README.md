#weirdos clean 
